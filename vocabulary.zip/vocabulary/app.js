document.getElementById('fetch-btn').addEventListener('click', () => {
  const word = document.getElementById('word-input').value.trim().toLowerCase();

  // If no word is entered, show an error
  if (!word) {
    displayError("Please enter a word.");
    return;
  }

  // Fetch word details dynamically
  fetchWordDetails(word);
});

function fetchWordDetails(word) {
  const apiUrl = `https://api.dictionaryapi.dev/api/v2/entries/en/${word}`;

  fetch(apiUrl)
    .then(response => response.json())
    .then(data => {
      // Handle cases where the word isn't found
      if (!data || data.title === "No Definitions Found") {
        displayError("Word not found.");
        return;
      }

      const wordDetails = data[0];
      const meaning = wordDetails.meanings[0].definitions[0].definition;
      const partOfSpeech = wordDetails.meanings[0].partOfSpeech;
      const synonyms = wordDetails.meanings[0].synonyms || [];
      const antonyms = wordDetails.meanings[0].antonyms || [];

      displayWordDetails(word, meaning, partOfSpeech, synonyms, antonyms);
    })
    .catch(error => {
      console.error("Error fetching word details:", error);
      displayError("An error occurred while fetching word details.");
    });
}

function displayWordDetails(word, meaning, partOfSpeech, synonyms, antonyms) {
  const resultDiv = document.getElementById('results');

  resultDiv.innerHTML = `
    <h2>Word: ${word}</h2>
    <div class="columns">
      <div class="column">
        <h3>Meaning</h3>
        <p>${meaning}</p>
      </div>
      <div class="column">
        <h3>Part of Speech</h3>
        <p>${partOfSpeech}</p>
      </div>
      <div class="column">
        <h3>Synonyms</h3>
        <ul>${synonyms.length > 0 ? synonyms.map(syn => `<li>${syn}</li>`).join('') : '<li>No synonyms available</li>'}</ul>
      </div>
      <div class="column">
        <h3>Antonyms</h3>
        <ul>${antonyms.length > 0 ? antonyms.map(ant => `<li>${ant}</li>`).join('') : '<li>No antonyms available</li>'}</ul>
      </div>
    </div>
  `;
}

function displayError(message) {
  const resultDiv = document.getElementById('results');
  resultDiv.innerHTML = `<p id="error-message">${message}</p>`;
}
